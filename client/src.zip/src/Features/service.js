import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const initialState = {
    posts: [],
    comments: [],
    likes: [],
    services: [],
    status: 'idle',
    error: null,
};

const postSlice = createSlice({
    name: "posts",
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
                        .addCase(saveService.pending, (state) => {
                state.status = "loading";
            })
            .addCase(saveService.fulfilled, (state, action) => {
                state.status = "succeeded";
                state.services.push(action.payload); // Add new service
            })
            .addCase(saveService.rejected, (state, action) => {
                state.status = "failed";
                state.error = action.error.message;
            })
            .addCase(getServices.pending, (state) => {
                state.status = "loading";
            })
            .addCase(getServices.fulfilled, (state, action) => {
                state.status = "succeeded";
                state.services = action.payload; // Fetch all services
            })
            .addCase(getServices.rejected, (state, action) => {
                state.status = "failed";
                state.error = action.error.message;
            });
    },
});

// Thunks for Services
export const saveService = createAsyncThunk("services/saveService", async (serviceData) => {
    try {
        const response = await axios.post('http://localhost:3001/services', serviceData);
        return response.data.service; // Return the service to Redux
    } catch (error) {
        console.log(error);
    }
});

export const getServices = createAsyncThunk("services/getServices", async () => {
    try {
        const response = await axios.get("http://localhost:3001/getservices");
        return response.data.services;
    } catch (error) {
        console.log(error);
    }
});



export default postSlice.reducer;
