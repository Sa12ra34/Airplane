export const UserData=[
    {
        fristname:"Ahmed",
        lastname:"ALHarthi",
        email:"ah123@gmail.com",
        password:"12365"
    },
    {
        name:"Sara",
        lastname:"ALHarthi",
        email:"sare3@gmail.com",
        password:"76543"
    },
];